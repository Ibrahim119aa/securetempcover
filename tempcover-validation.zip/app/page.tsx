import { Calendar, Twitter, Facebook, Youtube, Linkedin } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"

export default function TempCoverValidation() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4">
          {/* Top navigation */}
          <div className="flex justify-end items-center py-2 text-sm">
            <div className="flex items-center space-x-4 text-blue-600">
              <a href="#" className="hover:underline">
                Who we cover - eligibility
              </a>
              <span className="text-gray-300">|</span>
              <a href="#" className="hover:underline">
                Why choose Tempcover?
              </a>
              <span className="text-gray-300">|</span>
              <a href="#" className="hover:underline">
                FAQ's
              </a>
              <div className="flex items-center space-x-1 ml-4">
                <div className="w-6 h-6 bg-blue-400 flex items-center justify-center">
                  <Twitter className="w-4 h-4 text-white" />
                </div>
                <div className="w-6 h-6 bg-blue-600 flex items-center justify-center">
                  <Facebook className="w-4 h-4 text-white" />
                </div>
                <div className="w-6 h-6 bg-red-600 flex items-center justify-center">
                  <Youtube className="w-4 h-4 text-white" />
                </div>
                <div className="w-6 h-6 bg-blue-700 flex items-center justify-center">
                  <Linkedin className="w-4 h-4 text-white" />
                </div>
                <div className="w-6 h-6 bg-red-500 flex items-center justify-center text-white text-xs font-bold">
                  G+
                </div>
              </div>
            </div>
          </div>

          {/* Main header */}
          <div className="flex items-center justify-between py-6">
            <div className="flex items-center">
              <div className="text-4xl font-bold text-blue-600 mr-2">+</div>
              <div className="text-4xl font-bold text-blue-600">tempcover</div>
            </div>
            <div className="text-right">
              <h1 className="text-3xl font-bold text-blue-600 mb-1">SHORT TERM INSURANCE</h1>
              <p className="text-blue-600 text-sm">
                We are the UK's largest temporary and short term insurance provider.
              </p>
            </div>
          </div>
        </div>
      </header>

      {/* Main content */}
      <main className="max-w-4xl mx-auto px-4 py-12">
        <div className="text-center mb-8">
          <h2 className="text-4xl font-bold text-gray-800 mb-4">USER VALIDATION</h2>
          <p className="text-gray-600 text-lg">
            FOR SECURITY PURPOSES, BEFORE ACCESSING YOUR POLICY DOCUMENTS, PLEASE CONFIRM THE FOLLOWING INFORMATION.
          </p>
        </div>

        <div className="flex justify-center">
          <div className="w-full max-w-2xl">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {/* Left column - Form */}
              <div className="space-y-6">
                <div>
                  <Label htmlFor="surname" className="text-blue-600 font-semibold text-right block mb-2">
                    Policyholder surname
                  </Label>
                  <Input id="surname" placeholder="Surname" className="w-full" />
                </div>

                <div>
                  <Label htmlFor="dob" className="text-blue-600 font-semibold text-right block mb-2">
                    Policyholder date of birth
                  </Label>
                  <div className="relative">
                    <Input id="dob" placeholder="Date of birth" className="w-full pr-10" />
                    <Calendar className="absolute right-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                  </div>
                </div>

                <div>
                  <Label htmlFor="startdate" className="text-blue-600 font-semibold text-right block mb-2">
                    Policy start date
                  </Label>
                  <div className="relative">
                    <Input id="startdate" placeholder="Policy start date" className="w-full pr-10" />
                    <Calendar className="absolute right-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                  </div>
                </div>

                {/* reCAPTCHA */}
                <div className="flex items-center space-x-3 bg-gray-100 p-4 border">
                  <input type="checkbox" className="w-6 h-6" />
                  <span className="text-gray-700">{"I'm not a robot"}</span>
                  <div className="ml-auto">
                    <div className="text-xs text-gray-500">
                      <div>reCAPTCHA</div>
                      <div>Privacy - Terms</div>
                    </div>
                  </div>
                </div>

                <Button className="bg-green-600 hover:bg-green-700 text-white px-8 py-2 font-semibold">SUBMIT</Button>
              </div>

              {/* Right column - Reference info */}
              <div className="space-y-4">
                <div className="border border-gray-300 p-4">
                  <div className="text-sm text-gray-600 mb-1">Your reference:</div>
                  <div className="font-bold text-gray-800">TCV-MOT-44072540</div>
                </div>
                <div className="border border-gray-300 p-4">
                  <div className="text-sm text-gray-600 mb-1">Policy:</div>
                  <div className="font-bold text-gray-800">Fully comprehensive cover</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}
